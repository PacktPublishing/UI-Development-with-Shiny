
fluidPage(
  
  navlistPanel(
    "Movies explorer", id = "navList",
    
    tabPanel(
      "Budgets over time", value = "graph",
      sliderInput("year", "Year", min = 1893, max = 2005,
                  value = c(1945, 2005), sep = ""),
      textInput("title", "Title"),
      selectInput("genre", "Which genre?", 
                  c("Action", "Animation", "Comedy", "Drama", 
                    "Documentary", "Romance", "Short")),
      plotOutput("budgetYear", height = "300px")),
    tabPanel("Movie picker", value = "table", 
             tableOutput("moviePicker"), 
             uiOutput("listMovies"))
  )
)

