
navbarPage("Movies explorer",
           id = "navBar",
           tabPanel(
             "Budgets over time", value = "graph",
             sliderInput("year", "Year", min = 1893, max = 2005,
                         value = c(1945, 2005), sep = ""),
             textInput("title", "Title"),
             selectInput("genre", "Which genre?", 
                         c("Action", "Animation", "Comedy", "Drama", 
                           "Documentary", "Romance", "Short")),
             plotOutput("budgetYear", height = "300px")),
           tabPanel(
             "Movie picker", value = "table",
             tableOutput("moviePicker"), 
             uiOutput("listMovies")),
           navbarMenu("Menu...",
                      tabPanel("About", value = "about",
                               p("This application was made 
                                          by Chris Beeley")),
                      tabPanel("Reference", value = "reference",
                               p("For more details see ", 
                                 a("https://shiny.rstudio.com/reference/shiny/latest/navbarPage.html")))
           )
)

